<?php

namespace App\Http\Controllers;
use App\Models\taskTodo;

use Illuminate\Http\Request;

class TodoController extends Controller
{
    public function index(){

        $todo = taskTodo::all();                    // Eloquent query to fetch all the data from the table  
        return view('index')->with('todos', $todo); // returns the view 'index' along with all created todo list
    
    }
    public function create(){
        return view('create');         // returns the view 'index' 
    }

        public function store(){

            // validate whether all the data is passed
            try {
                $this->validate(request(), [
                    'name' => ['required'],
                    'description' => ['required']
                ]);
            } catch (ValidationException $e) {
            }
    
            
            $data = request()->all();
        
            $task_todos = new taskTodo();
            //On the left is the field name in DB and on the right is field name in Form/view
            $task_todos->name = $data['name'];
            $task_todos->description = $data['description'];
            $task_todos->save();
    
            session()->flash('success', 'Todo created succesfully');
    
            return redirect('/');  // returns to the index page
    
    }

    public function details(taskTodo $todo){

        return view('details')->with('todos', $todo);
    
    }
    
    // function to show the selected item to edit
    public function edit(taskTodo $todo){
        return view('edit')->with('todos', $todo);   
    }

    public function update(taskTodo $todo){

        try {
            $this->validate(request(), [
                'name' => ['required'],
                'description' => ['required'],
           
            ]);
        } catch (ValidationException $e) {
        }

        $data = request()->all();

       
        $todo->name = $data['name'];
        $todo->description = $data['description'];
        $todo->save();

        session()->flash('success', 'Todo updated successfully');

        return redirect('/');

    }


    public function delete(taskTodo $todo){
        $todo->delete();
        session()->flash('success', 'Todo delted successfully');
        return redirect('/');
    
    }
}
